"""
Output writers for scraped data.

Supports JSONL (streaming, resumable) and CSV (final export).
"""
import json
import csv
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Optional

import pandas as pd

from config import settings

logger = logging.getLogger(__name__)


class JSONLWriter:
    """
    Write records to JSONL (JSON Lines) format.
    
    Supports:
    - Streaming writes (one record at a time)
    - Deduplication via key function
    - Atomic writes (temp file + rename)
    """
    
    def __init__(self, output_path: Path, key_fn: Optional[callable] = None):
        """
        Args:
            output_path: Path to output file
            key_fn: Function to extract dedup key from record
        """
        self.output_path = output_path
        self.key_fn = key_fn
        self._seen_keys: set = set()
        self._count = 0
        
        # Load existing keys if file exists
        if self.output_path.exists() and self.key_fn:
            self._load_existing_keys()
    
    def _load_existing_keys(self):
        """Load keys from existing file for deduplication."""
        try:
            with open(self.output_path, 'r') as f:
                for line in f:
                    if line.strip():
                        record = json.loads(line)
                        key = self.key_fn(record)
                        self._seen_keys.add(key)
            logger.info(f"Loaded {len(self._seen_keys)} existing keys")
        except Exception as e:
            logger.warning(f"Failed to load existing keys: {e}")
    
    def write(self, record: dict) -> bool:
        """
        Write a single record to the file.
        
        Returns:
            True if written, False if duplicate
        """
        # Add metadata
        record["scraped_at"] = datetime.now(timezone.utc).isoformat()
        
        # Check for duplicates
        if self.key_fn:
            key = self.key_fn(record)
            if key in self._seen_keys:
                logger.debug(f"Skipping duplicate: {key}")
                return False
            self._seen_keys.add(key)
        
        # Append to file
        with open(self.output_path, 'a') as f:
            f.write(json.dumps(record, ensure_ascii=False) + '\n')
        
        self._count += 1
        return True
    
    def write_many(self, records: list[dict]) -> int:
        """
        Write multiple records.
        
        Returns:
            Number of records written (excluding duplicates)
        """
        written = 0
        for record in records:
            if self.write(record):
                written += 1
        return written
    
    @property
    def count(self) -> int:
        """Number of records written in this session."""
        return self._count


class CSVWriter:
    """
    Write records to CSV format.
    
    Flattens nested structures for tabular output.
    """
    
    def __init__(self, output_path: Path, columns: Optional[list[str]] = None):
        self.output_path = output_path
        self.columns = columns
        self._records: list[dict] = []
    
    def write(self, record: dict):
        """Add record to buffer."""
        flat = self._flatten(record)
        self._records.append(flat)
    
    def write_many(self, records: list[dict]):
        """Add multiple records to buffer."""
        for record in records:
            self.write(record)
    
    def flush(self):
        """Write buffered records to CSV file."""
        if not self._records:
            logger.warning("No records to write")
            return
        
        df = pd.DataFrame(self._records)
        
        # Reorder columns if specified
        if self.columns:
            existing = [c for c in self.columns if c in df.columns]
            other = [c for c in df.columns if c not in self.columns]
            df = df[existing + other]
        
        df.to_csv(self.output_path, index=False)
        logger.info(f"Wrote {len(self._records)} records to {self.output_path}")
    
    def _flatten(self, record: dict, prefix: str = '') -> dict:
        """Flatten nested dict/list structures."""
        flat = {}
        
        for key, value in record.items():
            new_key = f"{prefix}{key}" if prefix else key
            
            if isinstance(value, dict):
                flat.update(self._flatten(value, f"{new_key}_"))
            elif isinstance(value, list):
                # For lists, join simple values or count complex ones
                if value and isinstance(value[0], dict):
                    flat[f"{new_key}_count"] = len(value)
                    # Optionally serialize as JSON string
                    flat[new_key] = json.dumps(value)
                else:
                    flat[new_key] = "; ".join(str(v) for v in value)
            else:
                flat[new_key] = value
        
        return flat


def jsonl_to_csv(jsonl_path: Path, csv_path: Path, columns: Optional[list[str]] = None):
    """
    Convert JSONL file to CSV.
    
    Args:
        jsonl_path: Input JSONL file
        csv_path: Output CSV file
        columns: Optional column ordering
    """
    records = []
    
    with open(jsonl_path, 'r') as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line))
    
    if not records:
        logger.warning(f"No records in {jsonl_path}")
        return
    
    writer = CSVWriter(csv_path, columns)
    writer.write_many(records)
    writer.flush()


def merge_data(
    maintenance_path: Path,
    vehicle_specs_path: Path,
    output_path: Path,
):
    """
    Merge maintenance schedules with vehicle specs.
    
    Args:
        maintenance_path: JSONL with maintenance data
        vehicle_specs_path: JSONL with FuelEconomy.gov data
        output_path: Output JSONL with merged data
    """
    # Load maintenance data
    maintenance = {}
    with open(maintenance_path, 'r') as f:
        for line in f:
            if line.strip():
                record = json.loads(line)
                key = (record["model"], record["year"])
                maintenance[key] = record
    
    # Load vehicle specs
    specs = {}
    if vehicle_specs_path.exists():
        with open(vehicle_specs_path, 'r') as f:
            for line in f:
                if line.strip():
                    record = json.loads(line)
                    # Group by model/year, keep first variant as representative
                    key = (record.get("model", ""), record.get("year"))
                    if key not in specs:
                        specs[key] = record
    
    # Merge
    merged = []
    for key, maint in maintenance.items():
        spec = specs.get(key, {})
        
        combined = {
            **maint,
            "engine_displacement": spec.get("engine_displacement"),
            "cylinders": spec.get("cylinders"),
            "transmission": spec.get("transmission"),
            "drive": spec.get("drive"),
            "fuel_type": spec.get("fuel_type"),
            "mpg_city": spec.get("mpg_city"),
            "mpg_highway": spec.get("mpg_highway"),
            "mpg_combined": spec.get("mpg_combined"),
            "vehicle_class": spec.get("vehicle_class"),
        }
        merged.append(combined)
    
    # Write merged output
    with open(output_path, 'w') as f:
        for record in merged:
            f.write(json.dumps(record, ensure_ascii=False) + '\n')
    
    logger.info(f"Merged {len(merged)} records to {output_path}")
